/*
Copyright (C) 2001 StrmnNrmn

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

#ifndef CORE_INTERRUPT_H_
#define CORE_INTERRUPT_H_

#include "Core/CPU.h"
#include "Ultra/ultra_R4300.h"


void R4300_Exception_TLB( u32 virtual_address, u32 exception_code, u32 exception_vector );
void R4300_Exception_Break();
void R4300_Exception_Syscall();
void R4300_Exception_CopUnusuable();

// Update the CAUSE_IP3 value after MI_INTR_MASK_REG or MI_INTR_REG changes
inline void R4300_Interrupt_UpdateCause3()
{
	//
	// If any interrupts pending when they are unmasked, the interrupt fires
	//
	if ((Memory_MI_GetRegister(MI_INTR_MASK_REG) &
		 Memory_MI_GetRegister(MI_INTR_REG)) == 0)
	{
		// Clear the Cause register
		ctx.cpuState.CPUControl[C0_CAUSE]._u32 &= ~CAUSE_IP3;
	}
	else
	{
		ctx.cpuState.CPUControl[C0_CAUSE]._u32 |= CAUSE_IP3;
		ctx.cpuState.AddJob( CPU_CHECK_INTERRUPTS );
	}
}

void R4300_Handle_Exception();
void R4300_Handle_Interrupt();

#ifdef DAEDALUS_PROFILE_EXECUTION
extern u32 gNumExceptions;
extern u32 gNumInterrupts;
#endif


#endif // CORE_INTERRUPT_H_
