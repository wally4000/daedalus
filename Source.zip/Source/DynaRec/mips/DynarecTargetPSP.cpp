/*
Copyright (C) 2006 StrmnNrmn

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/


#include "Base/Types.h"
#include "DynarecTargetPSP.h"

namespace
{
//const bool	gIsTemporary[] =
//{
//	true,	//PspReg_R0 = 0,
//	true,	//PspReg_AT,
//	true,	//PspReg_V0,
//	true,	//PspReg_V1,
//	true,	//PspReg_A0,
//	true,	//PspReg_A1,
//	true,	//PspReg_A2,
//	true,	//PspReg_A3,
//	true,	//PspReg_T0,
//	true,	//PspReg_T1,
//	true,	//PspReg_T2,
//	true,	//PspReg_T3,
//	true,	//PspReg_T4,
//	true,	//PspReg_T5,
//	true,	//PspReg_T6,
//	true,	//PspReg_T7,
//	false,	//PspReg_S0,
//	false,	//PspReg_S1,
//	false,	//PspReg_S2,
//	false,	//PspReg_S3,
//	false,	//PspReg_S4,
//	false,	//PspReg_S5,
//	false,	//PspReg_S6,
//	false,	//PspReg_S7,
//	true,	//PspReg_T8,
//	true,	//PspReg_T9,
//	true,	//PspReg_K0,
//	true,	//PspReg_K1,
//	true,	//PspReg_GP,
//	true,	//PspReg_SP,
//	false,	//PspReg_S8,
//	true,	//PspReg_RA,
//};
}

//bool	PspReg_IsTemporary( EPspReg psp_reg )
//{
//	return gIsTemporary[ psp_reg ];
//}
