#pragma once

#include <string>

namespace UI
{
	std::string DrawRomSelector();
}