
#ifndef UTILITY_PATHS_H
#define UTILITY_PATHS_H


#include <filesystem>


std::filesystem::path setBasePath(const std::filesystem::path& path);
#endif //UTILITY_PATHS_H